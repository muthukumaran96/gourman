export const images = [
  {
    id: 1,
    url: "assets/images/cake1.jpg"
  }, 
  {
    id: 2,
    url: "assets/images/cake2.jpg"
  },
  {
    id: 3,
    url: "assets/images/cake3.jpg"
  },
  {
    id: 4,
    url: "assets/images/dedert1.jpg"   
  }
];